/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uff.ic.lleme.tcc00328.trabalhos.s20192.MarcosF_YanI_HenriqueY_DavidH.lobisomen;

/**
 *
 * @author MarcosFrederico
 */
public class DiaNoite {

    private int horario;

    public void setHorario() {

    }

    public int getHorario() {
        return horario;
    }
}
