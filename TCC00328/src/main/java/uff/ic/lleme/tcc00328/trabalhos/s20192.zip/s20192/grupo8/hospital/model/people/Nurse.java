package uff.ic.lleme.tcc00328.trabalhos.s20192.Geraldo_Fernando_Rodrigo.hospital.model.people;

import uff.ic.lleme.tcc00328.trabalhos.s20192.Geraldo_Rodrigo_Fernando.model.misc.Cpf;

public class Nurse extends Staff {

    public Nurse(String name, Cpf cpf, String birthDate, String bloodType, String gender) {
        super(name, cpf, birthDate, bloodType, gender);
    }
}
