package uff.ic.lleme.tcc00328.trabalhos.s20192.grupo3.supermercado;

public class Visor {

    public static void main(String[] args) {
        Supermercado s1 = new Supermercado();
        s1.abre();
        s1.compras();
    }

}
