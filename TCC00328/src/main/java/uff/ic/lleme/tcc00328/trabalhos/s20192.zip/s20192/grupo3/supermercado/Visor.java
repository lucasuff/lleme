
package uff.ic.lleme.tcc00328.trabalhos.s20192.Trabalho_PedroBazilio_VictorBrandao_Felipeesser.visor;

public class Visor {
 
    public static void main(String[] args) {
       Supermercado s1=new Supermercado(); 
       s1.abre();
       s1.compras();
    }
    
}

