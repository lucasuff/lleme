package elements;

import java.util.ArrayList;

public class Bd<data> {
	ArrayList<data> table = new ArrayList<data>();
}
