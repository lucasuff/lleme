# EM CONSTRUÇÃO



ER'S:


https://drive.google.com/open?id=1TEM-i43oJXeo_I2DfPIW2OvNwVyj3PHF

TABELA:
https://drive.google.com/open?id=1w6zh_KDZqsALyLbe7ai_XNJkB_0qfTqP


APRESENTAÇÃO :

https://drive.google.com/open?id=11Zvl4-4GqrLoyWrOuqxNqsJo9riY3HD2FH_M9yImQMg
