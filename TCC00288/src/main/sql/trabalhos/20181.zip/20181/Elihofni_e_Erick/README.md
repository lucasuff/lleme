# TCC00.288---Bancos-de-Dados-II 

- [Modelo Entidade-Relacionamento](https://drive.google.com/file/d/1IQwob8gDZiFNycrgXe_ESnb_aqMjy5yP/view?usp=sharing)
