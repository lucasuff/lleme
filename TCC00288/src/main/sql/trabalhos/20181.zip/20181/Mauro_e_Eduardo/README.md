# DatabaseProject
Final work for BD2

Based on Instagram 

link for ER (anyone with link can edit)
https://drive.google.com/file/d/15QH-lgESRlu7iv7rPD7OBSW9nS9RBZPu/view?usp=sharing

link for presentation
https://docs.google.com/presentation/d/1Z5-7i5VSmCl00j1F6hv9sx7izVyKfPrkaSN40rO3pqI/edit?usp=sharing
