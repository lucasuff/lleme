- O "main ()" é encontrado no arquivo "servicioatendimiento.cpp". E usamos a seguinte linha de comando para executá-lo:
    g++ servicioatendimiento.cpp -o main

- Este trabalho também foi carregado para o nosso próprio repositório:
    https://github.com/joselhuillca/Trabalho-Final-ED.git

- Os "slides" que explicam a estrutura do trabalho estão em:
    Apresentação do trabalho.pdf