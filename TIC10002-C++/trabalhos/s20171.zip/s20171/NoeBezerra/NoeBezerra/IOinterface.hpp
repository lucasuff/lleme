/*
 * IOinterface.h
 *
 *  Created on: 3 de jun de 2017
 *      Author: noedelima
 */

#ifndef IOINTERFACE_HPP_
#define IOINTERFACE_HPP_

#include "sales.hpp"
tree<tree<saling, int>, int> getdata(string path, string file, string extension);
#endif /* IOINTERFACE_HPP_ */
