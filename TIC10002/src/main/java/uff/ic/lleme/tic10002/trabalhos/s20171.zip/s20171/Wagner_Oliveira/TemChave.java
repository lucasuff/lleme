package uff.ic.lleme.tic10002.trabalhos.s20171.Wagner_Oliveira;

public interface TemChave<K> {

    public K getChave();
}
