package uff.ic.lleme.tic10002.trabalhos.s20181.Lucas_e_Erick.teste;

/*package br.uff.ed.teste;

import java.lang.instrument.Instrumentation;

public class TamanhoDeObjeto {
    private static Instrumentation instrumentation;

    public static void premain(String args, Instrumentation inst) {
        instrumentation = inst;
    }

    public static long getObjectSize(Object o) {
        return instrumentation.getObjectSize(o);
    }




}
 */
