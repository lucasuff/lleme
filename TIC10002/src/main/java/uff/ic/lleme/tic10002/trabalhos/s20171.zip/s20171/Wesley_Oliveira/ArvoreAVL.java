/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uff.ic.lleme.tic10002.trabalhos.s20171.Wesley_Oliveira;

import java.util.ArrayList;

/**
 *
 * @author Wesley Oliveira
 */
public class ArvoreAVL {

    protected NoAVL raiz;

    public void inserir(int k, Venda venda) {
        NoAVL n = new NoAVL(k, venda);
        inserirAVL(this.raiz, n, venda);
    }

    public void inserirAVL(NoAVL aComparar, NoAVL aInserir, Venda venda) {

        if (aComparar == null)
            this.raiz = aInserir;
        else if (aInserir.getChave() < aComparar.getChave())

            if (aComparar.getEsquerda() == null) {
                aComparar.setEsquerda(aInserir);
                aInserir.setPai(aComparar);
                verificarBalanceamento(aComparar);

            } else
                inserirAVL(aComparar.getEsquerda(), aInserir, venda);
        else if (aInserir.getChave() > aComparar.getChave())

            if (aComparar.getDireita() == null) {
                aComparar.setDireita(aInserir);
                aInserir.setPai(aComparar);
                verificarBalanceamento(aComparar);

            } else
                inserirAVL(aComparar.getDireita(), aInserir, venda);
        else if (aInserir.getChave() == aComparar.getChave())
            aComparar.getLista().adicionarNo(venda); //// Achou o nó já existente então o objeto venda deve ser inserido na ListaEncadeada já existente.
    }

    public void verificarBalanceamento(NoAVL atual) {
        setBalanceamento(atual);
        int balanceamento = atual.getBalanceamento();

        if (balanceamento == -2)

            if (altura(atual.getEsquerda().getEsquerda()) >= altura(atual.getEsquerda().getDireita()))
                atual = rotacaoDireita(atual);
            else
                atual = duplaRotacaoEsquerdaDireita(atual);
        else if (balanceamento == 2)

            if (altura(atual.getDireita().getDireita()) >= altura(atual.getDireita().getEsquerda()))
                atual = rotacaoEsquerda(atual);
            else
                atual = duplaRotacaoDireitaEsquerda(atual);

        if (atual.getPai() != null)
            verificarBalanceamento(atual.getPai());
        else
            this.raiz = atual;
    }

    public void remover(int k) {
        removerAVL(this.raiz, k);
    }

    public void removerAVL(NoAVL atual, int k) {
        if (atual == null)
            return;
        else if (atual.getChave() > k)
            removerAVL(atual.getEsquerda(), k);
        else if (atual.getChave() < k)
            removerAVL(atual.getDireita(), k);
        else if (atual.getChave() == k)
            removerNoEncontrado(atual);
    }

    public void removerNoEncontrado(NoAVL aRemover) {
        NoAVL r;

        if (aRemover.getEsquerda() == null || aRemover.getDireita() == null) {

            if (aRemover.getPai() == null) {
                this.raiz = null;
                aRemover = null;
                return;
            }
            r = aRemover;

        } else {
            r = sucessor(aRemover);
            aRemover.setChave(r.getChave());
        }

        NoAVL p;
        if (r.getEsquerda() != null)
            p = r.getEsquerda();
        else
            p = r.getDireita();

        if (p != null)
            p.setPai(r.getPai());

        if (r.getPai() == null)
            this.raiz = p;
        else {
            if (r == r.getPai().getEsquerda())
                r.getPai().setEsquerda(p);
            else
                r.getPai().setDireita(p);
            verificarBalanceamento(r.getPai());
        }
        r = null;
    }

    public NoAVL rotacaoEsquerda(NoAVL inicial) {

        NoAVL direita = inicial.getDireita();
        direita.setPai(inicial.getPai());

        inicial.setDireita(direita.getEsquerda());

        if (inicial.getDireita() != null)
            inicial.getDireita().setPai(inicial);

        direita.setEsquerda(inicial);
        inicial.setPai(direita);

        if (direita.getPai() != null)

            if (direita.getPai().getDireita() == inicial)
                direita.getPai().setDireita(direita);
            else if (direita.getPai().getEsquerda() == inicial)
                direita.getPai().setEsquerda(direita);

        setBalanceamento(inicial);
        setBalanceamento(direita);

        return direita;
    }

    public NoAVL rotacaoDireita(NoAVL inicial) {

        NoAVL esquerda = inicial.getEsquerda();
        esquerda.setPai(inicial.getPai());

        inicial.setEsquerda(esquerda.getDireita());

        if (inicial.getEsquerda() != null)
            inicial.getEsquerda().setPai(inicial);

        esquerda.setDireita(inicial);
        inicial.setPai(esquerda);

        if (esquerda.getPai() != null)

            if (esquerda.getPai().getDireita() == inicial)
                esquerda.getPai().setDireita(esquerda);
            else if (esquerda.getPai().getEsquerda() == inicial)
                esquerda.getPai().setEsquerda(esquerda);

        setBalanceamento(inicial);
        setBalanceamento(esquerda);

        return esquerda;
    }

    public NoAVL duplaRotacaoEsquerdaDireita(NoAVL inicial) {
        inicial.setEsquerda(rotacaoEsquerda(inicial.getEsquerda()));
        return rotacaoDireita(inicial);
    }

    public NoAVL duplaRotacaoDireitaEsquerda(NoAVL inicial) {
        inicial.setDireita(rotacaoDireita(inicial.getDireita()));
        return rotacaoEsquerda(inicial);
    }

    public NoAVL sucessor(NoAVL q) {
        if (q.getDireita() != null) {
            NoAVL r = q.getDireita();
            while (r.getEsquerda() != null)
                r = r.getEsquerda();
            return r;
        } else {
            NoAVL p = q.getPai();
            while (p != null && q == p.getDireita()) {
                q = p;
                p = q.getPai();
            }
            return p;
        }
    }

    private int altura(NoAVL atual) {
        if (atual == null)
            return -1;

        if (atual.getEsquerda() == null && atual.getDireita() == null)
            return 0;
        else if (atual.getEsquerda() == null)
            return 1 + altura(atual.getDireita());
        else if (atual.getDireita() == null)
            return 1 + altura(atual.getEsquerda());
        else
            return 1 + Math.max(altura(atual.getEsquerda()), altura(atual.getDireita()));
    }

    private void setBalanceamento(NoAVL no) {
        no.setBalanceamento(altura(no.getDireita()) - altura(no.getEsquerda()));
    }

    final protected ArrayList<NoAVL> inorder() {
        ArrayList<NoAVL> ret = new ArrayList<NoAVL>();
        inorder(raiz, ret);
        return ret;
    }

    final protected void inorder(NoAVL no, ArrayList<NoAVL> lista) {
        if (no == null)
            return;
        inorder(no.getEsquerda(), lista);
        lista.add(no);
        inorder(no.getDireita(), lista);
    }

    public NoAVL buscar(int chave) {
        if (this.raiz != null)
            return buscar(raiz, chave);
        else
            return null;
    }

    private NoAVL buscar(NoAVL no, int chave) {
        if (no.getChave() == chave)
            return no;

        else if (chave > no.getChave() && no.getDireita() != null)
            return buscar(no.getDireita(), chave);
        else if (chave < no.getChave() && no.getEsquerda() != null)
            return buscar(no.getEsquerda(), chave);
        else
            return null;
    }

}
