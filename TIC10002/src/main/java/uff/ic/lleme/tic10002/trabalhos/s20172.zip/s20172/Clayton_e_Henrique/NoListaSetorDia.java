package uff.ic.lleme.tic10002.trabalhos.s20172.Clayton_e_Henrique;

public class NoListaSetorDia extends NoLista {
	
	public int setor;
	public int dia;

}
