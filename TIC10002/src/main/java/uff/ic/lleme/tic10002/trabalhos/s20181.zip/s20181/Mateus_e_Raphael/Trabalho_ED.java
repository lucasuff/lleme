package uff.ic.lleme.tic10002.trabalhos.s20181.Mateus_e_Raphael;

/**
 *
 * @author raphael
 */
public class Trabalho_ED {

    public static void main(String[] args) {

        FilaPrioridade fila = new FilaPrioridade();
        fila.atendimento();

    }

}
