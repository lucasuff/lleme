package uff.ic.lleme.tic10002.trabalhos.s20181.Luiz_Gustavo_Dias.model;

public class Cliente {

    public int cpf;
    public String nome;
    public int idade;
    //ListaAssuntos assuntos;

    public Cliente(int cpf, String nome, int idade) {
        this.cpf = cpf;
        this.nome = nome;
        this.idade = idade;
    }
}
