package uff.ic.lleme.tic10002.trabalhos.s20181.Marcos_Raylan;

import uff.ic.lleme.tic10002.trabalhos.s20181.Marcos_Raylan.MenuOption;

/*Name: Marcos Raylan Sousa Matos
 Class: main
 Due Date: 10/05/2018
 Date Submitted: 14/06/2018
 */
//import clientWaitingRoom.*;
public class UserInterface {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        MenuOption menu = new MenuOption();
        menu.Menu();
    }

}
