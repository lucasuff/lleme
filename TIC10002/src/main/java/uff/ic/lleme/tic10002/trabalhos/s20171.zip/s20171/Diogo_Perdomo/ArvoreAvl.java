package uff.ic.lleme.tic10002.trabalhos.s20171.Diogo_Perdomo;

import java.util.ArrayList;

public class ArvoreAvl {

    protected No raiz;
    protected String tipo;
    private Double Total = 0.0;
    // CORRECAO: uma lista de vendas é mais eficiente porque sempre extrairemos todas as vendas.
    Hash hash = new Hash();

    public ArvoreAvl(String tipo) {
        this.tipo = tipo;
    }

    public void inserir(int Filial, int Ano_mes, int cod_vendedor, double totalvendido) {
        No n;
        if (this.tipo.equals("filial"))
            n = new No(Filial, Ano_mes, cod_vendedor, totalvendido, Filial); // n.setChave(Filial);
        else
            n = new No(Filial, Ano_mes, cod_vendedor, totalvendido, Ano_mes); //n.setChave(Ano_mes);
        // System.out.println("Data escolhida para Chave");

        inserirAVL(this.raiz, n);

    }

    public void inserirAVL(No aComparar, No aInserir) {

        if (aComparar == null)
            this.raiz = aInserir;
        else if (aInserir.getChave() < aComparar.getChave())

            if (aComparar.getEsquerda() == null) {
                aComparar.setEsquerda(aInserir);
                aInserir.setPai(aComparar);
                verificarBalanceamento(aComparar);

            } else
                inserirAVL(aComparar.getEsquerda(), aInserir);
        else if (aInserir.getChave() > aComparar.getChave())

            if (aComparar.getDireita() == null) {
                aComparar.setDireita(aInserir);
                aInserir.setPai(aComparar);
                verificarBalanceamento(aComparar);

            } else
                inserirAVL(aComparar.getDireita(), aInserir);
        else {
            ListaFilial l_filial = aInserir.getFilial();

            aComparar.insertvenda(l_filial.getFilial(), l_filial.getAno_mes(), l_filial.getcod_vendedor(), l_filial.gettotalvendido());
            // System.out.println("O no" + aInserir + " ja existe");// O nó já existe
        }
    }
    //public void inserirAVL(No aComparar, No aInserir)

    public Double LocalizarNo(No raiz, int Filial) {
        ListaFilial l_filial = null;
        Double Total = null;
        //System.out.println("getChave="+raiz.getChave());

        if (Filial < raiz.getChave())

            if (raiz.getEsquerda() == null) {
                //Nao existe

            } else
                return LocalizarNo(raiz.getEsquerda(), Filial);
        else if (Filial > raiz.getChave())

            if (raiz.getDireita() == null) {
                // nao existe

            } else
                return LocalizarNo(raiz.getDireita(), Filial);
        else {
            l_filial = raiz.getFilial();
            Total = l_filial.imprime_lista();
            //System.out.println(Total);
            //aComparar.insertvenda(l_filial.getAno_mes(),l_filial.getcod_vendedor(),l_filial.gettotalvendido());
            // System.out.println("ENCNTROU ="+raiz.getChave());
        }

        return Total;
    }

    public No pesquisaRange(No raiz, int minimo, int maximo) {
        ListaFilial l_filial = null;

        if (raiz == null)
            return null;
        if (raiz.getChave() > minimo)
            pesquisaRange(raiz.getEsquerda(), minimo, maximo);
        if (minimo <= raiz.getChave() && raiz.getChave() <= maximo) {
            // System.out.println("getChave" + raiz.getChave());
            l_filial = raiz.getFilial();
            if (this.tipo.equals("filial"))

                hash.insertHash(l_filial);
            else
                hash.insertHash_data(l_filial); // System.out.println("getChave" + raiz.getChave() + "getFilial=" raiz.);

            if (Total == null)
                Total = l_filial.imprime_lista();
            else
                Total += l_filial.imprime_lista();
        }
        if (raiz.getChave() < maximo)
            pesquisaRange(raiz.getDireita(), minimo, maximo);

        return raiz;
    }

    public void verificarBalanceamento(No atual) {
        setBalanceamento(atual);
        int balanceamento = atual.getBalanceamento();

        if (balanceamento == -2)

            if (altura(atual.getEsquerda().getEsquerda()) >= altura(atual.getEsquerda().getDireita()))
                atual = rotacaoDireita(atual);
            else
                atual = duplaRotacaoEsquerdaDireita(atual);
        else if (balanceamento == 2)

            if (altura(atual.getDireita().getDireita()) >= altura(atual.getDireita().getEsquerda()))
                atual = rotacaoEsquerda(atual);
            else
                atual = duplaRotacaoDireitaEsquerda(atual);

        if (atual.getPai() != null)
            verificarBalanceamento(atual.getPai());
        else
            this.raiz = atual;
    }

    public void remover(int k) {
        removerAVL(this.raiz, k);
    }

    public void removerAVL(No atual, int k) {
        if (atual == null)
            return;
        else if (atual.getChave() > k)
            removerAVL(atual.getEsquerda(), k);
        else if (atual.getChave() < k)
            removerAVL(atual.getDireita(), k);
        else if (atual.getChave() == k)
            removerNoEncontrado(atual);
    }

    public void removerNoEncontrado(No aRemover) {
        No r;

        if (aRemover.getEsquerda() == null || aRemover.getDireita() == null) {

            if (aRemover.getPai() == null) {
                this.raiz = null;
                aRemover = null;
                return;
            }
            r = aRemover;

        } else {
            r = sucessor(aRemover);
            aRemover.setChave(r.getChave());
        }

        No p;
        if (r.getEsquerda() != null)
            p = r.getEsquerda();
        else
            p = r.getDireita();

        if (p != null)
            p.setPai(r.getPai());

        if (r.getPai() == null)
            this.raiz = p;
        else {
            if (r == r.getPai().getEsquerda())
                r.getPai().setEsquerda(p);
            else
                r.getPai().setDireita(p);
            verificarBalanceamento(r.getPai());
        }
        r = null;
    }

    public No rotacaoEsquerda(No inicial) {

        No direita = inicial.getDireita();
        direita.setPai(inicial.getPai());

        inicial.setDireita(direita.getEsquerda());

        if (inicial.getDireita() != null)
            inicial.getDireita().setPai(inicial);

        direita.setEsquerda(inicial);
        inicial.setPai(direita);

        if (direita.getPai() != null)

            if (direita.getPai().getDireita() == inicial)
                direita.getPai().setDireita(direita);
            else if (direita.getPai().getEsquerda() == inicial)
                direita.getPai().setEsquerda(direita);

        setBalanceamento(inicial);
        setBalanceamento(direita);

        return direita;
    }

    public No rotacaoDireita(No inicial) {

        No esquerda = inicial.getEsquerda();
        esquerda.setPai(inicial.getPai());

        inicial.setEsquerda(esquerda.getDireita());

        if (inicial.getEsquerda() != null)
            inicial.getEsquerda().setPai(inicial);

        esquerda.setDireita(inicial);
        inicial.setPai(esquerda);

        if (esquerda.getPai() != null)

            if (esquerda.getPai().getDireita() == inicial)
                esquerda.getPai().setDireita(esquerda);
            else if (esquerda.getPai().getEsquerda() == inicial)
                esquerda.getPai().setEsquerda(esquerda);

        setBalanceamento(inicial);
        setBalanceamento(esquerda);

        return esquerda;
    }

    public No duplaRotacaoEsquerdaDireita(No inicial) {
        inicial.setEsquerda(rotacaoEsquerda(inicial.getEsquerda()));
        return rotacaoDireita(inicial);
    }

    public No duplaRotacaoDireitaEsquerda(No inicial) {
        inicial.setDireita(rotacaoDireita(inicial.getDireita()));
        return rotacaoEsquerda(inicial);
    }

    public No sucessor(No q) {
        if (q.getDireita() != null) {
            No r = q.getDireita();
            while (r.getEsquerda() != null)
                r = r.getEsquerda();
            return r;
        } else {
            No p = q.getPai();
            while (p != null && q == p.getDireita()) {
                q = p;
                p = q.getPai();
            }
            return p;
        }
    }

    private int altura(No atual) {
        if (atual == null)
            return -1;

        if (atual.getEsquerda() == null && atual.getDireita() == null)
            return 0;
        else if (atual.getEsquerda() == null)
            return 1 + altura(atual.getDireita());
        else if (atual.getDireita() == null)
            return 1 + altura(atual.getEsquerda());
        else
            return 1 + Math.max(altura(atual.getEsquerda()), altura(atual.getDireita()));
    }

    private void setBalanceamento(No no) {
        no.setBalanceamento(altura(no.getDireita()) - altura(no.getEsquerda()));
    }

    final protected ArrayList<No> inorder() {
        ArrayList<No> ret = new ArrayList<No>();
        inorder(raiz, ret);
        return ret;
    }

    final protected void inorder(No no, ArrayList<No> lista) {
        if (no == null)
            return;
        inorder(no.getEsquerda(), lista);
        lista.add(no);
        inorder(no.getDireita(), lista);
    }

    public void print() {
        raiz.printTree();
    }

    public Double getTotal() {
        double temp = Total;
        Total = null;
        return temp;
    }

    public void Limpa_total() {
        Total = null;
    }

    public void pesquisaHash(int chave) {
        hash.pesquisaHash(chave);
    }

}
