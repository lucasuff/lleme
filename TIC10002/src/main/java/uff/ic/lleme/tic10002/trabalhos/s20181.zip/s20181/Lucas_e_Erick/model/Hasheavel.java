package uff.ic.lleme.tic10002.trabalhos.s20181.Lucas_e_Erick.model;

public interface Hasheavel {

    public long hashcode();
}
