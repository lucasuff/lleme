package uff.ic.lleme.tic10002.trabalhos.s20172.Clayton_e_Henrique;

public abstract class ListaEncadeada {

	public NoLista primeiroNo;
	
	public ListaEncadeada() {
		this.primeiroNo = null;
	}
	
}
