/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uff.ic.lleme.tic10002.trabalhos.s20181.Breno_e_Vinicius.model;

/**
 *
 * @author Breno Atendimento: Eliminar o Prioritario da Lista de Espera
 *
 */
public class Atendimento {

    public void Atendimento(Cliente atendimento) {
        //ClientesEsperando.MakeHeap.remover();
    }

    public void simAtendimento(String[] assuntos) {

        //int[] tempo = IntStream.generate(() -> new Random().nextInt(11)).limit(n).toArray();
//        for (int i = 0; i<assuntos.length; i++)
//            tempo[i] = IntStream.generate(() -> new Random().nextInt(11)).limit(n).toArray();;
    }

}
