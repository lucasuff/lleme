package uff.ic.lleme.tic10002.trabalhos.s20172.Clayton_e_Henrique;

public class NoListaDeFluxos extends NoLista {

	public Fluxo fluxo;
	
}
