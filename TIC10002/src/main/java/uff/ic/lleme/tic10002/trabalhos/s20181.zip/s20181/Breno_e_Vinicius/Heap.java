/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uff.ic.lleme.tic10002.trabalhos.s20181.Breno_e_Vinicius;

/**
 *
 * @author Breno
 */
public class Heap {

    //int nmax = ClientesEsperando.nmax;
    //public ClientesEsperando.Cliente[] heap = new ClientesEsperando.Cliente[nmax];
//    private void subir(int i){
//
//       int pai= i/2;
//
//        if(pai>=1){
//            //Atualizar prioridade pai
//            if (heap[i].prioridade>heap[pai].prioridade){
//                trocar(i,pai);
//                subir(pai);
//            }
//        }
//    }
//    private void descer(int i){
//       int filho=2*i+1;
//       if (filho<n){
//           if (filho<n-1)// Tem filho da esquerda
//                if (heap[filho].prioridade<heap[filho+1].prioridade){
//                    filho= filho+1;
//                }
//           if(heap[i].prioridade<heap[filho].prioridade){
//                    trocar(i,filho);
//                    descer(filho);
//           }
//       }
//    }
//
//    public void trocar(int i, int j){
//       Priorizacao aux= heap[i];
//       heap[i]= heap[j];
//       heap[j]= aux;
//    }
}
