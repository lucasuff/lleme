/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uff.ic.lleme.tic10002.trabalhos.s20171.Daniel_Pinheiro;

/**
 *
 * @author danieljunior
 */
public class DuplicatedItemException extends Exception {

    @Override
    public String getMessage() {
        return "Already exists this content"; //To change body of generated methods, choose Tools | Templates.
    }

}
