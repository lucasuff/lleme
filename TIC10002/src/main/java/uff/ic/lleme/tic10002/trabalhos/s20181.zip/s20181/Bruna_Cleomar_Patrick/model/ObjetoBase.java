package uff.ic.lleme.tic10002.trabalhos.s20181.Bruna_Cleomar_Patrick.model;

public abstract class ObjetoBase extends Object {

    public abstract String getChave();
}
